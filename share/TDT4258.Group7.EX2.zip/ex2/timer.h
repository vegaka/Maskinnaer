#ifndef TIMER_H
#define TIMER_H

void setup_timer(uint32_t period);

#endif
