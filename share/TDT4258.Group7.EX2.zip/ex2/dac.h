#ifndef DAC_H
#define DAC_H

void setup_dac();

#endif
